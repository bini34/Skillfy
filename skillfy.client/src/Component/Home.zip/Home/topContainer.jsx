import Header from '../Header/Header';
import './topContainer.css'
import './container.css'
function TopContainer(){
    return(
        <div  className='topContainer Container'>
            <Header/>
            <div className="top-text">
                <h1>Distant learning for further expansion</h1>
                <p>Choose from over 100,000 online video courses with new additions published every month.</p>
                <button className="top-button">Get Started Now for Free</button>
            </div>
            <div className="text-info">
                <div className='text-info-child'>
                    100k Online Courses
                </div> 
                <div className='text-info-child'>
                    Expert Instruction
                </div>
                <div className='text-info-child'>
                    Lifetime access
                </div>
            </div>
        </div>
    );
}
export default TopContainer;