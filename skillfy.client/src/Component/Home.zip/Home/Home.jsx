
import Header from '../Header/Header';
import './Home.css';
import my from '../../assets/image/young.png'
import TopCategories from './CatagiesContainer'
import TopContainer from './topContainer';
import CourseContainer from './courseContainer'
function Home(){
    return(

        <div className="mainContainer">
            <TopContainer/>
            <TopCategories/>
            <CourseContainer/>
                <div  className="testimonyContainer Container">
                    
                </div>
                <div className="aboutContainer Container">
                </div>
        </div>
    );
}
export default Home;

