 function CourseContainer(){
    return(
        <div  className="courseContainer Container">
                    
        </div>
    );
}
export default CourseContainer;